var callback = function() {
	// Callback goodness here
}


setupPage (
	[
		{
			"template" : "message",
			"data": {
				"message" : "This is dynamic content."
			}
		}
	], callback
);
