var callback = function() {
	// Callback goodness here
}


page.setup(
	[
		{
			"template" : "message",
			"data": {
				"message" : "Hello World!"
			}
		}
	], callback
);
