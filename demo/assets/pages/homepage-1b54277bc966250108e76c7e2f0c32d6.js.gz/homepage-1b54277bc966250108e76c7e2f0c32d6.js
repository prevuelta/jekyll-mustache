var callback = function() {
	// Callback goodness here
}


setup(
	[
		{
			"template" : "message",
			"data": {
				"message" : "This is dynamic content."
			}
		}
	], callback
);
